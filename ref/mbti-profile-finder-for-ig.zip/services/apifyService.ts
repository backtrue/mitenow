import { Profile } from '../types';

const ACTOR_ID = 'jar_stargazer/instagram-bio-scraper';
const API_BASE_URL = 'https://api.apify.com/v2';

const mapApifyResultToProfile = (result: any): Profile | null => {
  if (!result.username) {
    return null;
  }
  return {
    username: result.username,
    bio: result.biography || '',
    followers: result.followers_count || 0,
    avatarUrl: result.profile_pic_url || 'https://upload.wikimedia.org/wikipedia/commons/a/ac/Default_pfp.jpg',
  };
};

/**
 * Starts the Apify actor run.
 * @returns {Promise<{id: string, defaultDatasetId: string}>} The run ID and dataset ID.
 */
const startActorRun = async (mbti: string, token: string) => {
    const url = `${API_BASE_URL}/acts/${ACTOR_ID}/runs?token=${token}`;
    const runInput = {
        searchQueries: [mbti],
        resultsLimit: 50, // Get a decent number of candidates for language analysis
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(runInput),
    });

    if (!response.ok) {
        const errorText = await response.text();
        console.error("Failed to start Apify actor:", response.status, errorText);
        if (response.status === 403) throw new Error(`Apify request failed (403 Forbidden). Check if your API token is correct.`);
        if (response.status === 404) throw new Error(`Apify actor '${ACTOR_ID}' not found in your account.`);
        throw new Error(`Failed to start Apify scraper. Status: ${response.status}`);
    }
    const runData = await response.json();
    return runData.data;
};

/**
 * Polls the Apify API until the actor run is finished.
 */
const waitForRunToFinish = async (runId: string, token: string) => {
    const url = `${API_BASE_URL}/runs/${runId}?token=${token}`;
    
    // Set a max wait time to avoid infinite loops
    const maxWaitSeconds = 300; // 5 minutes
    const pollIntervalSeconds = 5;
    const maxRetries = maxWaitSeconds / pollIntervalSeconds;
    let retries = 0;

    while (retries < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, pollIntervalSeconds * 1000));

        const response = await fetch(url);
        if (!response.ok) {
            // Don't throw on a single failed poll, maybe a temp network issue
            console.warn(`Polling Apify run status failed with status: ${response.status}`);
            retries++;
            continue;
        }
        
        const runData = await response.json();
        const status = runData.data.status;
        
        if (status === 'SUCCEEDED') {
            return; // Success!
        }
        if (['FAILED', 'TIMEDOUT', 'ABORTED'].includes(status)) {
            throw new Error(`Apify actor run ended with status: ${status}. Check your Apify dashboard for details.`);
        }
        
        retries++;
    }

    throw new Error('Apify actor run timed out. The scraping process took too long to complete.');
};


/**
 * Fetches the results from the actor's dataset.
 * @returns {Promise<any[]>} The array of result items.
 */
const getDatasetItems = async (datasetId: string, token: string): Promise<any[]> => {
    const url = `${API_BASE_URL}/datasets/${datasetId}/items?token=${token}&format=json`;
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch dataset items from Apify. Status: ${response.status}`);
    }
    return response.json();
};


export const discoverProfilesWithApify = async (
    mbti: string, 
    token: string, 
    onProgress: (message: string) => void
): Promise<Profile[]> => {
    if (!mbti) return [];
    if (!token) throw new Error("Apify API Token is missing.");

    try {
        // 1. Start the run
        onProgress('Phase 1/2: Starting Instagram scraper...');
        const { id: runId, defaultDatasetId } = await startActorRun(mbti, token);
        
        // 2. Wait for it to finish, providing progress feedback
        onProgress('Phase 1/2: Scraping in progress, this can take a few minutes...');
        await waitForRunToFinish(runId, token);

        // 3. Get the results
        onProgress('Phase 1/2: Scraper finished, fetching results...');
        const items = await getDatasetItems(defaultDatasetId, token);
        
        if (!Array.isArray(items)) {
            console.error("Unexpected response format from Apify dataset:", items);
            throw new Error("Received an unexpected data format from Apify. Expected an array of results.");
        }
        
        return items.map(mapApifyResultToProfile).filter((p): p is Profile => p !== null);

    } catch (error) {
        console.error("Error during Apify process:", error);
        if (error instanceof TypeError && error.message === 'Failed to fetch') {
            throw new Error("A network error occurred. Please check your internet connection and browser's console for more details.");
        }
        if (error instanceof Error) {
            throw error;
        }
        throw new Error("An unexpected error occurred while running the Apify scraper.");
    }
};