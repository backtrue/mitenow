import { GoogleGenAI } from "@google/genai";
import { SearchCriteria, Profile, ProfileSearchResult } from '../types';
import { discoverProfilesWithApify } from './apifyService';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Uses Gemini to analyze the primary language of a given text.
 * @param bio The text content of a user's bio.
 * @returns The detected language as a string (e.g., "English").
 */
const analyzeBioLanguage = async (bio: string): Promise<string> => {
  if (!bio.trim()) {
    return "Unknown"; // Can't determine language of an empty bio.
  }

  const prompt = `
    What is the primary language of the following text?
    Return only the language name, and nothing else.
    For example: "English", "Spanish", "Japanese".

    Text: "${bio}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error(`Error analyzing language for bio: "${bio}"`, error);
    // In case of an error, return "Unknown" to allow filtering to proceed.
    return "Unknown";
  }
};


/**
 * Orchestrates the profile finding process.
 * 1. Uses Apify to find profiles by MBTI keyword in their bio.
 * 2. Uses Gemini to analyze the language of each profile's bio.
 * 3. Filters the results based on language and follower count.
 * @param criteria The user's search criteria.
 * @param onProgress A callback to update the UI with loading messages.
 * @returns A promise that resolves to the search results.
 */
export const findProfiles = async (
  criteria: SearchCriteria,
  onProgress: (message: string) => void
): Promise<ProfileSearchResult> => {
  const { mbti, language, followers, apifyToken } = criteria;

  // Step 1: Discover and fetch initial profiles from Instagram using Apify
  // The onProgress callback is now passed down to be managed by the apifyService
  const initialProfiles = await discoverProfilesWithApify(mbti, apifyToken, onProgress);

  if (initialProfiles.length === 0) {
    // This message is shown if Apify returns nothing.
    throw new Error("Phase 1: Apify didn't find any profiles with that MBTI type in their bio.");
  }

  // Step 2: Analyze language for each profile using Gemini
  onProgress(`Phase 2/2: Analyzing language for ${initialProfiles.length} profiles...`);
  const profilesWithLanguage = await Promise.all(
    initialProfiles.map(async (profile) => {
      const detectedLanguage = await analyzeBioLanguage(profile.bio);
      return { ...profile, language: detectedLanguage };
    })
  );

  // Step 3: Filter profiles based on the desired language and follower count
  const finalProfiles = profilesWithLanguage.filter(profile =>
    profile.language.toLowerCase() === language.toLowerCase() &&
    profile.followers >= followers
  );

  return { profiles: finalProfiles, sources: [] }; // Grounding sources are no longer applicable in this workflow.
};