
import { Profile } from '../types';

function escapeCsvCell(cellData: string | number): string {
  const stringData = String(cellData);
  // If the cell contains a comma, double quote, or newline, wrap it in double quotes
  if (/[",\n]/.test(stringData)) {
    // Also, double up any existing double quotes
    return `"${stringData.replace(/"/g, '""')}"`;
  }
  return stringData;
}

export const exportToCSV = (profiles: Profile[], mbti: string) => {
  if (profiles.length === 0) {
    alert("No profiles to export.");
    return;
  }

  const headers = ['Username', 'Followers', 'Bio', 'Avatar URL'];
  const csvRows = [headers.join(',')];

  profiles.forEach(profile => {
    const row = [
      escapeCsvCell(profile.username),
      escapeCsvCell(profile.followers),
      escapeCsvCell(profile.bio),
      escapeCsvCell(profile.avatarUrl)
    ];
    csvRows.push(row.join(','));
  });

  const csvString = csvRows.join('\n');
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  
  const date = new Date().toISOString().split('T')[0];
  link.setAttribute('download', `ig_profiles_${mbti}_${date}.csv`);
  
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
