export interface Profile {
  username: string;
  bio: string;
  followers: number;
  avatarUrl: string;
}

export interface SearchCriteria {
  mbti: string;
  language: string;
  followers: number;
  apifyToken: string;
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface ProfileSearchResult {
  profiles: Profile[];
  sources: GroundingSource[];
}
