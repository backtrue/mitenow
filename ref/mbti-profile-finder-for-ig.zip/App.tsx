import React, { useState, useCallback } from 'react';
import { SearchCriteria, Profile, GroundingSource } from './types';
import { findProfiles } from './services/geminiService';
import { exportToCSV } from './utils/csvExporter';
import { SearchIcon, ChevronLeftIcon, UserGroupIcon, DownloadIcon } from './components/icons';

const MBTI_TYPES = [
  "INTJ", "INTP", "ENTJ", "ENTP",
  "INFJ", "INFP", "ENFJ", "ENFP",
  "ISTJ", "ISFJ", "ESTJ", "ESFJ",
  "ISTP", "ISFP", "ESTP", "ESFP"
];

const LANGUAGES = [
  "English", "Spanish", "Mandarin Chinese", "Japanese", "Korean", "French", "German", "Portuguese", "Russian", "Arabic"
];

// Sub-components defined outside the main component to prevent re-creation on re-renders
const ProfileCard: React.FC<{ profile: Profile }> = ({ profile }) => (
  <a 
    href={`https://www.instagram.com/${profile.username}/`} 
    target="_blank" 
    rel="noopener noreferrer"
    className="flex items-center space-x-4 p-3 hover:bg-gray-800 transition-colors duration-200 cursor-pointer"
  >
    <img src={profile.avatarUrl} alt={profile.username} className="w-14 h-14 rounded-full object-cover border-2 border-gray-600 bg-gray-700" />
    <div className="flex-1 min-w-0"> {/* Added min-w-0 to prevent text overflow issues */}
      <p className="font-bold text-white text-md truncate">{profile.username}</p>
      <p className="text-gray-400 text-sm truncate">{profile.bio}</p>
      <p className="text-gray-500 text-xs">{profile.followers.toLocaleString()} followers</p>
    </div>
  </a>
);

// Note: This component is no longer used as the new workflow doesn't use Google Search grounding.
// It's kept here in case the logic changes back, but it won't be rendered.
const SourcesList: React.FC<{ sources: GroundingSource[] }> = ({ sources }) => (
    <div className="p-4 border-t border-gray-800">
        <h3 className="text-lg font-semibold text-gray-300 mb-2">Discovery Sources</h3>
        <p className="text-xs text-gray-500 mb-3">The initial list of profiles was discovered using Google Search. Detailed data fetched via Apify. All profiles are publicly accessible.</p>
        <ul className="list-disc list-inside space-y-1">
            {sources.map((source, index) => (
                <li key={index} className="truncate">
                    <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline text-sm">
                        {source.title || source.uri}
                    </a>
                </li>
            ))}
        </ul>
    </div>
);


const LoadingComponent: React.FC<{ message: string }> = ({ message }) => (
  <div className="flex flex-col justify-center items-center h-full text-center">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-100 mb-4"></div>
    <p className="text-white font-semibold">{message}</p>
    <p className="text-gray-400 text-sm">This may take a moment, especially on the first run...</p>
  </div>
);

const EmptyState: React.FC = () => (
  <div className="text-center py-20 px-4">
    <UserGroupIcon className="mx-auto h-16 w-16 text-gray-500" />
    <h3 className="mt-2 text-lg font-medium text-white">Find Your Audience</h3>
    <p className="mt-1 text-sm text-gray-400">
      Enter your criteria and Apify Token to start searching.
    </p>
  </div>
);

export default function App() {
  const [searchCriteria, setSearchCriteria] = useState<Omit<SearchCriteria, 'apifyToken'>>({
    mbti: 'INTJ',
    language: 'English',
    followers: 1000,
  });
  const [apifyToken, setApifyToken] = useState<string>('');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async () => {
    if (!searchCriteria.mbti) {
      setError("Please enter an MBTI type.");
      return;
    }
    if (!apifyToken) {
      setError("Please enter your Apify API Token.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setProfiles([]);
    setSources([]); // Will always be empty with the new workflow

    try {
      const fullCriteria: SearchCriteria = { ...searchCriteria, apifyToken };
      // Pass a callback to get progress updates
      const { profiles: results } = await findProfiles(
        fullCriteria,
        (message) => setLoadingMessage(message)
      );
      
      setProfiles(results);
      if (results.length === 0) {
        setError("No profiles found matching all criteria. Try being less specific with follower count or language.");
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [searchCriteria, apifyToken]);

  const handleExport = () => {
    exportToCSV(profiles, searchCriteria.mbti);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col font-sans">
      <header className="sticky top-0 z-10 bg-black/80 backdrop-blur-sm border-b border-gray-800 p-4">
        <div className="flex items-center space-x-3">
            <ChevronLeftIcon className="w-6 h-6 text-gray-300" />
            <div className="relative flex-1">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                    type="text"
                    value={searchCriteria.mbti}
                    onChange={(e) => setSearchCriteria(prev => ({ ...prev, mbti: e.target.value.toUpperCase() }))}
                    placeholder="Search MBTI (e.g., INTJ)"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
            </div>
        </div>
      </header>
      
      <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-gray-800">
        <div>
            <label htmlFor="language" className="block text-sm font-medium text-gray-400 mb-1">Language</label>
            <select
                id="language"
                value={searchCriteria.language}
                onChange={(e) => setSearchCriteria(prev => ({ ...prev, language: e.target.value }))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
                {LANGUAGES.map(lang => <option key={lang} value={lang}>{lang}</option>)}
            </select>
        </div>
        <div>
            <label htmlFor="followers" className="block text-sm font-medium text-gray-400 mb-1">Min Followers: {searchCriteria.followers.toLocaleString()}</label>
             <input
                id="followers"
                type="range"
                min="100"
                max="1000000"
                step="100"
                value={searchCriteria.followers}
                onChange={(e) => setSearchCriteria(prev => ({ ...prev, followers: parseInt(e.target.value, 10) }))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
        </div>
        <div className="md:col-span-2">
            <label htmlFor="apifyToken" className="block text-sm font-medium text-gray-400 mb-1">Apify API Token</label>
            <input
                id="apifyToken"
                type="password"
                value={apifyToken}
                onChange={(e) => setApifyToken(e.target.value)}
                placeholder="Enter your Apify API Token"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-xs text-gray-500 mt-1">
                Required for search. Get a free token from <a href="https://apify.com/" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Apify</a> and add the <a href="https://apify.com/jar_stargazer/instagram-bio-scraper" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Instagram Bio Scraper</a> actor to your account.
            </p>
        </div>
      </div>
       <div className="px-4 py-2 flex justify-between items-center">
            <h2 className="text-xl font-bold">Accounts</h2>
            {profiles.length > 0 && (
                 <button 
                    onClick={handleExport}
                    className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-200"
                    disabled={isLoading || profiles.length === 0}
                    >
                    <DownloadIcon className="w-5 h-5" />
                    <span>Export CSV</span>
                </button>
            )}
       </div>


      <main className="flex-1 overflow-y-auto">
        {isLoading ? (
          <LoadingComponent message={loadingMessage} />
        ) : error && profiles.length === 0 ? (
          <div className="text-center py-10 px-4">
            <p className="text-yellow-400">{error}</p>
          </div>
        ) : profiles.length > 0 ? (
          <>
            <div className="divide-y divide-gray-800">
              {profiles.map((profile, index) => <ProfileCard key={`${profile.username}-${index}`} profile={profile} />)}
            </div>
            {sources.length > 0 && <SourcesList sources={sources} />}
          </>
        ) : (
          <EmptyState />
        )}
      </main>

       <footer className="sticky bottom-0 z-10 p-4 bg-black/80 backdrop-blur-sm border-t border-gray-800">
            <button
                onClick={handleSearch}
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center"
            >
              {isLoading ? 'Searching...' : 'Find Profiles'}
            </button>        </footer>
    </div>
  );
}
