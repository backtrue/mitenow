
export interface Metrics {
  atr_pct: number;
  rvol: number;
  win_rate: string;
}

export interface Candidate {
  id: string;
  name: string;
  price: number;
  metrics: Metrics;
  score: number;
  ex_date: string;
  kline_pattern: string;
  technical_sentiment: 'BULLISH' | 'NEUTRAL' | 'BEARISH';
  institutional_flow: 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'SELL';
  sector: string;
  daily_value: string;
  volume_lots: number; // 新增：成交張數
  entry_range: string;
  target_price: number;
  stop_loss: number;
}

export enum RiskStatus {
  GREEN = 'GREEN',
  RED = 'RED',
  UNKNOWN = 'UNKNOWN'
}

export interface GlobalRisk {
  status: RiskStatus;
  pct: number;
  msg: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ScreeningResult {
  risk: GlobalRisk;
  candidates: Candidate[];
  sources: GroundingSource[];
  timestamp: string;
}
