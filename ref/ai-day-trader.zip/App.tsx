
import React, { useState, useEffect, useCallback } from 'react';
import { performMarketAnalysis } from './services/geminiService';
import { ScreeningResult } from './types';
import RiskBanner from './components/RiskBanner';
import StockTable from './components/StockTable';
import SourceLinks from './components/SourceLinks';

const App: React.FC = () => {
  const [data, setData] = useState<ScreeningResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  const today = new Date();
  const todayStr = `${today.getMonth() + 1}/${today.getDate()}`;

  const fetchAnalysis = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await performMarketAnalysis();
      setData(result);
      setLastUpdated(result.timestamp);
    } catch (err) {
      setError("AI 數據核對異常。請確認成交量與價格來源是否通暢。");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAnalysis();
  }, [fetchAnalysis]);

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-7xl mx-auto pb-24 text-slate-200">
      <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-gradient-to-br from-amber-500 to-red-600 p-2 rounded-lg shadow-lg shadow-amber-500/20">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight flex items-center gap-2">
              台股 AI 即時價量篩選器
              <span className="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-full font-bold align-middle uppercase tracking-widest animate-pulse">Live Quote</span>
            </h1>
          </div>
          <p className="text-slate-400 max-w-2xl font-medium">
            針對 <span className="text-amber-400 font-bold underline underline-offset-4">{todayStr}</span> 盤中數據：嚴格執行「高量能檢核」與「實時成交價」追蹤。自動過濾低量冷門股，為您提供最具執行力的當沖交易計畫。
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={fetchAnalysis}
            disabled={loading}
            className={`px-8 py-2.5 rounded-xl font-bold transition-all shadow-lg ${
              loading 
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed italic' 
              : 'bg-amber-600 hover:bg-amber-500 text-white shadow-orange-500/20 hover:-translate-y-0.5'
            }`}
          >
            {loading ? '正在同步今日數據...' : `更新 ${todayStr} 即時價量`}
          </button>
        </div>
      </header>

      {loading && !data ? (
        <div className="flex flex-col items-center justify-center py-32 space-y-6">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-amber-500/10 rounded-full"></div>
            <div className="w-20 h-20 border-4 border-amber-500 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-slate-200">正在核對 {todayStr} 即時成交價與張數...</p>
            <p className="text-slate-500 text-sm mt-2">AI 正在搜尋當前最新資訊，並為您重新演算進出場計畫。</p>
          </div>
        </div>
      ) : data ? (
        <main>
          <RiskBanner risk={data.risk} />
          
          <div className="mb-6 flex items-center justify-between">
            <h3 className="text-xl font-bold text-slate-200 flex items-center gap-2 font-mono">
              <span className="w-2 h-6 bg-amber-500 rounded-sm"></span>
              {todayStr} 盤中高能清單
            </h3>
            <span className="text-xs text-slate-500 font-mono italic">
              AI 數據同步時間: {data.timestamp}
            </span>
          </div>

          <StockTable candidates={data.candidates} />
          
          <SourceLinks sources={data.sources} />

          <footer className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 bg-slate-800/50 rounded-xl border border-slate-700/30">
              <h4 className="text-sm font-bold text-amber-400 mb-2">🎯 當日實時報價</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                數據來源包含各大財經入口網站。若 AI 抓取的報價與您的下單軟體有延遲，請以券商系統的即時五檔為準。
              </p>
            </div>
            <div className="p-5 bg-slate-800/50 rounded-xl border border-slate-700/30">
              <h4 className="text-sm font-bold text-red-400 mb-2">🌊 今日量能檢核</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                系統會動態獲取今日累積成交張數。量能不足 3,000 張的標的會被自動過濾，以避免流動性風險。
              </p>
            </div>
            <div className="p-5 bg-slate-800/50 rounded-xl border border-slate-700/30">
              <h4 className="text-sm font-bold text-emerald-400 mb-2">⚖️ 策略每日動態更新</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                進場區間、獲利點與停損點皆依據 {todayStr} 的盤中波動度 (ATR) 重新計算，而非參考歷史死數據。
              </p>
            </div>
          </footer>
        </main>
      ) : null}
    </div>
  );
};

export default App;
