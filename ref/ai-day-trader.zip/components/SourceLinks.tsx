
import React from 'react';
import { GroundingSource } from '../types';

interface SourceLinksProps {
  sources: GroundingSource[];
}

const SourceLinks: React.FC<SourceLinksProps> = ({ sources }) => {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-8 p-6 bg-slate-800/20 border border-slate-700/50 rounded-2xl">
      <h3 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
        </svg>
        數據分析參考來源 (Google Search Grounding)
      </h3>
      <div className="flex flex-wrap gap-2">
        {sources.map((source, idx) => (
          <a
            key={idx}
            href={source.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-full border border-slate-700 transition-colors inline-block max-w-xs truncate"
            title={source.title}
          >
            {source.title}
          </a>
        ))}
      </div>
    </div>
  );
};

export default SourceLinks;
