
import React from 'react';
import { Candidate } from '../types';

interface StockTableProps {
  candidates: Candidate[];
}

const StockTable: React.FC<StockTableProps> = ({ candidates }) => {
  const today = new Date();
  const dateDisplay = `${today.getMonth() + 1}/${today.getDate()}`;

  if (candidates.length === 0) {
    return (
      <div className="text-center py-20 bg-slate-800/30 rounded-2xl border border-slate-700/50">
        <p className="text-slate-400 font-medium">查無符合「今日高成交量」且「價格精確」的標的</p>
      </div>
    );
  }

  const getFlowTag = (flow: string) => {
    switch(flow) {
      case 'STRONG_BUY': return <span className="bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded text-[9px] font-bold">法人強買</span>;
      case 'BUY': return <span className="bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded text-[9px] font-bold">法人偏多</span>;
      default: return <span className="bg-slate-800 text-slate-500 px-2 py-0.5 rounded text-[9px]">籌碼中性</span>;
    }
  };

  return (
    <div className="overflow-x-auto bg-slate-800/30 rounded-2xl border border-slate-700/50 shadow-xl">
      <table className="w-full text-left border-collapse min-w-[1250px]">
        <thead className="bg-slate-900/50 text-slate-400 text-[11px] uppercase tracking-wider">
          <tr>
            <th className="px-6 py-4 font-bold">綜合評分</th>
            <th className="px-6 py-4 font-bold">標的 / 最後現價</th>
            <th className="px-6 py-4 font-bold">量能檢核 ({dateDisplay})</th>
            <th className="px-6 py-4 font-bold">當沖計畫</th>
            <th className="px-6 py-4 font-bold text-center">族群/籌碼</th>
            <th className="px-6 py-4 font-bold text-center">ATR%</th>
            <th className="px-6 py-4 font-bold text-center">查核</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-700/50 text-slate-300">
          {candidates.map((c) => (
            <tr key={c.id} className="hover:bg-slate-700/30 transition-colors group">
              <td className="px-6 py-6">
                <div className={`w-12 h-12 flex flex-col items-center justify-center rounded-xl font-black shadow-lg ${
                  c.score >= 80 ? 'bg-gradient-to-br from-red-500 to-orange-600 text-white' : 'bg-slate-700 text-slate-400'
                }`}>
                  <span className="text-lg">{c.score}</span>
                  <span className="text-[8px] opacity-70 font-bold">WIN%</span>
                </div>
              </td>
              <td className="px-6 py-6">
                <div className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors flex items-center gap-2">
                  {c.id} {c.name}
                  {c.technical_sentiment === 'BULLISH' && <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>}
                </div>
                <div className="mt-2 flex items-baseline gap-1.5">
                  <span className="text-2xl font-mono font-black text-amber-400 tracking-tighter">
                    {c.price.toFixed(2)}
                  </span>
                  <span className="text-[9px] bg-amber-400/10 text-amber-500 border border-amber-500/20 px-1 py-0.5 rounded font-bold uppercase tracking-tighter">Live Quote</span>
                </div>
              </td>
              <td className="px-6 py-6">
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-black font-mono ${c.volume_lots >= 10000 ? 'text-red-400' : 'text-slate-100'}`}>
                      {c.volume_lots.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">張</span>
                    </span>
                    {c.volume_lots >= 3000 ? (
                      <span className="bg-emerald-500/10 text-emerald-400 text-[8px] px-1.5 py-0.5 rounded-sm border border-emerald-500/20 font-bold">量能達標</span>
                    ) : (
                      <span className="bg-red-500/10 text-red-400 text-[8px] px-1.5 py-0.5 rounded-sm border border-red-500/20 font-bold">量能不足</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
                    <span>{c.daily_value} 億</span>
                    <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
                    <span>RVOL: <span className={c.metrics.rvol >= 1.5 ? 'text-red-400 font-bold' : ''}>{c.metrics.rvol}</span></span>
                  </div>
                </div>
              </td>
              <td className="px-6 py-6">
                <div className="grid grid-cols-3 gap-2 bg-slate-900/60 p-3 rounded-xl border border-slate-700/50 w-[300px] shadow-inner">
                  <div className="flex flex-col">
                    <span className="text-[9px] text-blue-400 font-black">進場</span>
                    <span className="text-xs font-mono text-blue-100 font-bold">{c.entry_range}</span>
                  </div>
                  <div className="flex flex-col border-x border-slate-700/50 px-3">
                    <span className="text-[9px] text-emerald-400 font-black">獲利</span>
                    <span className="text-xs font-mono text-emerald-100 font-bold">{c.target_price}</span>
                  </div>
                  <div className="flex flex-col pl-1">
                    <span className="text-[9px] text-red-400 font-black">停損</span>
                    <span className="text-xs font-mono text-red-100 font-bold">{c.stop_loss}</span>
                  </div>
                </div>
                <p className="text-[9px] text-slate-500 mt-2 italic truncate max-w-[300px]">"{c.kline_pattern}"</p>
              </td>
              <td className="px-6 py-6 text-center">
                <div className="flex flex-col items-center gap-2">
                  <span className="text-[10px] px-2.5 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded font-bold">
                    {c.sector}
                  </span>
                  {getFlowTag(c.institutional_flow)}
                </div>
              </td>
              <td className="px-6 py-6 text-center">
                <div className="flex flex-col">
                  <span className={`text-sm font-black ${c.metrics.atr_pct > 3.5 ? 'text-orange-400' : 'text-slate-400'}`}>
                    {c.metrics.atr_pct}%
                  </span>
                  <span className="text-[8px] text-slate-600 font-bold uppercase tracking-tighter">波動潛力</span>
                </div>
              </td>
              <td className="px-6 py-6 text-center">
                <a 
                  href={`https://tw.stock.yahoo.com/quote/${c.id}.TW/chart`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-slate-800 hover:bg-indigo-600/30 rounded-xl transition-all inline-block hover:scale-110 border border-slate-700 hover:border-indigo-500/50"
                  title="開啟 Yahoo 股市圖表"
                >
                  <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                  </svg>
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StockTable;
