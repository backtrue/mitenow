
import React from 'react';
import { GlobalRisk, RiskStatus } from '../types';

interface RiskBannerProps {
  risk: GlobalRisk;
}

const RiskBanner: React.FC<RiskBannerProps> = ({ risk }) => {
  const isRed = risk.status === RiskStatus.RED;

  return (
    <div className={`p-6 rounded-2xl mb-8 flex items-center justify-between border ${
      isRed 
      ? 'bg-red-900/20 border-red-500/50 text-red-100' 
      : 'bg-emerald-900/20 border-emerald-500/50 text-emerald-100'
    }`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${
          isRed ? 'bg-red-500 text-white animate-pulse' : 'bg-emerald-500 text-white'
        }`}>
          {isRed ? '🛑' : '🛡️'}
        </div>
        <div>
          <h2 className="text-xl font-bold tracking-tight">
            市場風控狀態: {isRed ? '停止交易 (RED)' : '運行安全 (GREEN)'}
          </h2>
          <p className="text-sm opacity-80">{risk.msg}</p>
        </div>
      </div>
      <div className="text-right">
        <div className="text-xs uppercase opacity-60 font-semibold tracking-widest">NQ=F 變動</div>
        <div className={`text-2xl font-mono font-bold ${isRed ? 'text-red-400' : 'text-emerald-400'}`}>
          {risk.pct > 0 ? '+' : ''}{risk.pct}%
        </div>
      </div>
    </div>
  );
};

export default RiskBanner;
