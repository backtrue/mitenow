
import { GoogleGenAI, Type } from "@google/genai";
import { ScreeningResult, GroundingSource } from "../types";

export const performMarketAnalysis = async (): Promise<ScreeningResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  // 動態獲取今日日期
  const now = new Date();
  const todayStr = `${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}`;
  
  const systemInstruction = `
    你是一位極度重視「數據即時性」與「流動性」的專業當沖交易員。
    今天的日期是 ${todayStr}。
    
    【核心任務：獲取當前即時數據】
    1. 現價 (price)：你必須從搜尋結果中提取標的在 ${todayStr} 的「最後成交價 (Last Trade Price)」。嚴禁使用歷史收盤價。
    2. 成交量 (volume_lots)：必須是 ${todayStr} 當日的即時成交張數。必須大於 3,000 張。
    3. 流動性閥值：成交金額必須大於 5 億台幣。
    
    【交易計畫計算】
    - 根據「最新的現價」與「盤中支撐壓力」，計算具體的 entry_range、target_price 與 stop_loss。
    - 若現價已經大幅超過目標價，請調低該標的的 score。

    返回格式必須嚴格遵守 JSON Schema。請務必透過 Google Search 確認標的的今日即時數據。
  `;

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      risk: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING },
          pct: { type: Type.NUMBER },
          msg: { type: Type.STRING }
        },
        required: ["status", "pct", "msg"]
      },
      candidates: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            name: { type: Type.STRING },
            price: { type: Type.NUMBER },
            metrics: {
              type: Type.OBJECT,
              properties: {
                atr_pct: { type: Type.NUMBER },
                rvol: { type: Type.NUMBER },
                win_rate: { type: Type.STRING }
              }
            },
            score: { type: Type.NUMBER },
            ex_date: { type: Type.STRING },
            kline_pattern: { type: Type.STRING },
            technical_sentiment: { type: Type.STRING, enum: ["BULLISH", "NEUTRAL", "BEARISH"] },
            institutional_flow: { type: Type.STRING, enum: ["STRONG_BUY", "BUY", "NEUTRAL", "SELL"] },
            sector: { type: Type.STRING },
            daily_value: { type: Type.STRING },
            volume_lots: { type: Type.INTEGER },
            entry_range: { type: Type.STRING },
            target_price: { type: Type.NUMBER },
            stop_loss: { type: Type.NUMBER }
          },
          required: ["id", "name", "price", "metrics", "score", "ex_date", "kline_pattern", "technical_sentiment", "institutional_flow", "sector", "daily_value", "volume_lots", "entry_range", "target_price", "stop_loss"]
        }
      }
    },
    required: ["risk", "candidates"]
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `請即時搜尋台股 ${todayStr} (今日) 的最新成交量、最後成交現價與即將除息標的。確保過濾低成交量個股，並提供精確的當沖價格建議。`,
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema
      }
    });

    const data = JSON.parse(response.text || "{}");
    const sources: GroundingSource[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web) {
          sources.push({ title: chunk.web.title || "即時市價來源", uri: chunk.web.uri });
        }
      });
    }

    return {
      ...data,
      sources: Array.from(new Map(sources.map(s => [s.uri, s])).values()),
      timestamp: new Date().toLocaleTimeString('zh-TW')
    } as ScreeningResult;
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};
